-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2018 at 10:43 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kiwari`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id_event` int(7) NOT NULL,
  `nama_event` varchar(30) NOT NULL,
  `foto_event` varchar(300) NOT NULL,
  `deskripsi_event` varchar(1000) NOT NULL,
  `tanggal_event` int(8) NOT NULL,
  `tanggal_post` varchar(25) NOT NULL,
  `nama_kota` varchar(25) NOT NULL,
  `lokasi` varchar(100) NOT NULL,
  `kontak` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id_event`, `nama_event`, `foto_event`, `deskripsi_event`, `tanggal_event`, `tanggal_post`, `nama_kota`, `lokasi`, `kontak`, `username`) VALUES
(5, 'tes 1', 'https://', 'a213ewf', 20180120, 'Nov 25, 2018', 'Gresik', 'asdfsad', '085777777', 'null'),
(6, 'tes2', 'alsdk', 'lsakd', 123122, 'Nov 25, 2018', 'Sidoarjo', 'asldk', '123123', 'null'),
(7, 'tes4', 'ewserew', 'efdsfds', 2019129, 'Nov 25, 2018', 'Surabaya', 'fgfdds', 'gfhdgf67', 'null'),
(8, 'tes3', ' hjb jhvl fji', 'mfhlxshfsroeogmcgkefu', 20180905, 'null', 'Jakarta', 'mxkigesyzugyrf', '2535828787', 'null'),
(9, 'tes4', 'mjfixuysef', 'hxiuyfmiryxw3746gmxfrfbiryf', 20180403, 'null', 'Gresik', 'hmxifuyfimgfg8ryf', '48542874', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `kota`
--

CREATE TABLE `kota` (
  `nama_kota` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kota`
--

INSERT INTO `kota` (`nama_kota`) VALUES
('Gresik'),
('Jakarta'),
('Sidoarjo'),
('Surabaya');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `full_name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`full_name`, `username`, `email`, `password`) VALUES
('Alam Al Mabruk', 'marvelalam', 'alamalmabruk@rocketmail.com', '123456'),
('Alam Al Mabruk', 'marvelalam2', 'alamalmabruk@rocketmail.com', '123456'),
('Manis Hanggraeni', 'mhanggra', 'majsbdufy@gmail.com', '987654');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id_event`);

--
-- Indexes for table `kota`
--
ALTER TABLE `kota`
  ADD PRIMARY KEY (`nama_kota`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id_event` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
