package koneksi;

import java.sql.*;

public class koneksi1 {
    
    public Connection cc;
    public Statement ss;
    public ResultSet rr;
    public static Connection conn;
    
    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/kiwari", "root", "");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return con;
    }
   
    public void Class() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            cc = DriverManager.getConnection("jdbc:mysql://localhost/kiwari", "root", "");
            System.out.println("koneksi sukses");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[]) {
        System.out.println(koneksi1.getConnection());
    }
}
