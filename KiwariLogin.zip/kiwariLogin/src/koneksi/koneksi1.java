package koneksi;
import java.sql.*;
    
    public class koneksi1{

    public static Object getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        public Connection cc;
        public Statement ss;
        public ResultSet rr;   
        

public void Class () {
    try{
        Class.forName("com.mysql.jdbc.Driver");
        cc=DriverManager.getConnection("jdbc:mysql://localhost/kiwari","root","");
        System.out.println("koneksi sukses");
}   
catch (Exception e){
    System.out.println (e);
    }
}
    public static void main(String args[]) {
        
    }
}
